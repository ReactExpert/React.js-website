import Api from './Api'

export default class UserApi extends Api {

  constructor(baseUrl) {
    super(baseUrl);
    this.baseUrl += '/user';
  }

  ViewProfile(userId, onSuccess, onError) {
    let url = `${this.baseUrl}/profile`;
    return this.get(url, { userId: userId }, onSuccess, onError);
  }

  Photos(userId, onSuccess, onError) {
    let url = `${this.baseUrl}/photos`;
    return this.get(url, { userId: userId }, onSuccess, onError);
  }

  UpdateProfile(profile, onSuccess, onError) {
    let url = `${this.baseUrl}/profile`;
    return this.post(url, profile, onSuccess, onError);
  }

  CompatibleUsers(userId, onSuccess, onError) {
    let url = `${this.baseUrl}/compatible`;
    return this.get(url, { userId: userId }, onSuccess, onError);
  }

  Action(userId, actionUserId, actionType, onSuccess, onError) {
    let url = `${this.baseUrl}/action`;
    return this.post(url, {
      userId: userId,
      actionUserId: actionUserId,
      actionType: actionType
    }, onSuccess, onError);
  }

  Favorites(userId, onSuccess, onError) {
    let url = `${this.baseUrl}/favorites`;
    return this.get(url, { userId: userId }, onSuccess, onError);
  }

  NewMatches(userId, onSuccess, onError) {
    let url = `${this.baseUrl}/matches/new`;
    return this.get(url, { userId: userId }, onSuccess, onError);
  }

  AllMatches(userId, onSuccess, onError) {
    let url = `${this.baseUrl}/matches/all`;
    return this.get(url, { userId: userId }, onSuccess, onError);
  }

  GetSearchPreferences(userId, onSuccess, onError) {
    let url = `${this.baseUrl}/preferences`;
    return this.get(url, { userId: userId }, onSuccess, onError);
  }

  UpdateSearchPreferences(userId, maxDistance, ageRange, lookingFor, withGender, onSuccess, onError) {
    let url = `${this.baseUrl}/preferences`;
    return this.post(url, {
      userId: userId,
      maxDistance: maxDistance,
      ageRange: ageRange,
      lookingFor: lookingFor,
      withGender: withGender
    }, onSuccess, onError);
  }

  GetAccountSettings(userId, onSuccess, onError) {
    let url = `${this.baseUrl}/settings`;
    return this.get(url, { userId: userId }, onSuccess, onError);
  }

  UpdateAccountSettings(userId, username, password, firstName, lastName, city, state, country, dateOfBirth, timeOfBirth, onSuccess, onError) {
    let url = `${this.baseUrl}/preferences`;
    return this.post(url, {
      userId: userId,
      username: username,
      password: password,
      firstName: firstName,
      lastName: lastName,
      city: city,
      state: state,
      country: country,
      dateOfBirth: dateOfBirth,
      timeOfBirth: timeOfBirth
    }, onSuccess, onError);
  }

}
