export default class Api {

  constructor(baseUrl) {
    this.baseUrl = baseUrl;
  }

  get(url, data, successCallback, errorCallback) {
    url += Api.convertObjectToUrlQueryString(data);
    return fetch(url, {
      method: 'get',
      headers: {
        'Accept': 'application/json'
      },
      mode: 'cors'
    }).then(Api.convertResponseToJSON)
      .then(successCallback)
      .catch(errorCallback);
  }

  post(url, data, successCallback, errorCallback) {
    url += Api.convertObjectToUrlQueryString(data);
    return fetch(url, {
      method: 'post',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      mode: 'cors',
      body: JSON.stringify(data)
    }).then(Api.convertResponseToJSON)
      .then(successCallback)
      .catch(errorCallback);
  }

  static convertObjectToUrlQueryString(data) {
    let getParams = '';

    if (typeof data === 'object' && data !== null) {
      let params = [];
      for (let prop in data) {
        if (data.hasOwnProperty(prop)) {
          params.push(`${encodeURIComponent(prop)}=${encodeURIComponent(data[prop])}`);
        }
      }
      getParams = '?' + params.join('&');
    }

    return getParams;
  }

  static convertResponseToJSON(response) {
    return response.json();
  }
}