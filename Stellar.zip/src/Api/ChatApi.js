import Api from './Api'

export default class ChatApi extends Api {

  constructor(baseUrl) {
    super(baseUrl);
    this.baseUrl += '/chat';
  }

  AllMessages(userId, onSuccess, onError) {
    let url = `${this.baseUrl}/messages/all`;
    return this.get(url, { userId: userId }, onSuccess, onError);
  }

  SendMessage(fromUserId, toUserId, timestamp, message, onSuccess, onError) {
    let url = `${this.baseUrl}/messages/new`;
    return this.post(url, {
      fromUserId: fromUserId,
      toUserId: toUserId,
      timestamp: timestamp,
      message: message
    }, onSuccess, onError);
  }

}