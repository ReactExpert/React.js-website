import Api from './Api'

export default class AstrologyApi extends Api {

  constructor(baseUrl) {
    super(baseUrl);
    this.baseUrl += '/astrology';
  }

  Compatibility(astrologySymbol1, astrologySymbol2, onSuccess, onError) {
    let url = `${this.baseUrl}/compatability`;
    return this.get(url, { astrologySymbol1: astrologySymbol1, astrologySymbol2: astrologySymbol2}, onSuccess, onError);
  }

  FunFact(astrologySymbol, onSuccess, onError) {
    let url = `${this.baseUrl}/fun_fact`;
    return this.get(url, { astrologySymbol: astrologySymbol }, onSuccess, onError);
  }

  Horoscope(astrologySymbol, type, onSuccess, onError) {
    let url = `${this.baseUrl}/horoscope`;
    return this.get(url, { astrologySymbol: astrologySymbol, type: type }, onSuccess, onError);
  }

  PersonalAnalysisReports(userId, astrologySymbol, onSuccess, onError) {
    let url = `${this.baseUrl}/analysis/report`;
    return this.get(url, { userId: userId, astrologySymbol: astrologySymbol }, onSuccess, onError);
  }

  PersonalAnalysisNatalChart(userId, astrologySymbol, onSuccess, onError) {
    let url = `${this.baseUrl}/analysis/natal`;
    return this.get(url, { userId: userId, astrologySymbol: astrologySymbol }, onSuccess, onError);
  }

}