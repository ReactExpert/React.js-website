export let EmailValidator = (text) => {
  if (!/\S+@\S+\.\S+/.test(text)) {
    return 'Please enter a valid e-mail address';
  }
  return '';
};

export let UsernameValidator = (text) => {
  let usernameLength = text.length;
  if (usernameLength < 6 || usernameLength > 64) {
    return 'Username must be between 6 and 64 characters';
  }
  return '';
};

export let PasswordValidator = (text) => {
  let passwordLength = text.length;
  if (passwordLength < 8 || passwordLength > 64) {
    return 'Password must be between 8 and 64 characters';
  }
  if (text.search(/[a-z]/i) < 0 || text.search(/\d/) < 0) {
    return 'Password must contain at least one letter and one number';
  }
  return '';
};

export let DateValidator = (text) => {
  if (!/\d{2}\/\d{2}\/\d{4}/.test(text)) {
    return 'Invalid Format (ex: 12/03/1992)';
  }
  return '';
};

export let TimeValidator = (text) => {
  if (!/\d{2}:\d{2} (AM|PM)/.test(text)) {
    return 'Invalid Format (ex: 04:16 PM)';
  }
  return '';
};
