import React , { Component } from 'react'
import { Link } from 'react-router-dom'
import backgroundImage from '../../../images/Backgrounds/404page.png'
import backgroundImage_768 from '../../../images/Backgrounds/404page_768.png'
import backgroundImage_667 from '../../../images/Backgrounds/404page_667.png'
import backgroundImage_568 from '../../../images/Backgrounds/404page_568.png'
import ErrorLogo from '../../../images/Backgrounds/404_logo.png'
import '../styles/Error404.css'
import Dimensions from 'react-dimensions'

class Error404 extends Component{
  constructor(props){
    super(props);
    this.state = {dimensions: 0};
    this.onImgLoad = this.onImgLoad.bind(this);
  }
  onImgLoad({target:img}) {
    this.setState({
      dimensions: img.offsetHeight
    });
  }
  render(){
    const BrowserHeight = this.props.containerHeight;
    const BrowserWidth = this.props.containerWidth;
    const imgheight = this.state.dimensions;
    let Offsetheight = BrowserHeight - imgheight;

    if ( Offsetheight < 0 )
      Offsetheight = 0

    const epwimage = (
      <img id="epwimage" onLoad={this.onImgLoad} src={backgroundImage} alt="Generic background" />
    );
    const epwimage_768 = (
      <img id="epwimage_768" onLoad={this.onImgLoad} src={backgroundImage_768} alt="Generic background" />
    );
    const epwimage_667 = (
        <img id="epwimage_667" onLoad={this.onImgLoad} src={backgroundImage_667} alt="667 Generic background" />
    );
    const epwimage_568 = (
        <img id="epwimage_568" onLoad={this.onImgLoad} src={backgroundImage_568} alt="568 Generic background" />
    );

    let final_epw = null;
    if(BrowserHeight < 769 && BrowserHeight > 667 && BrowserWidth <= 1024 && BrowserWidth > 411){
      final_epw = epwimage_768
    } else if(BrowserHeight <= 667 && BrowserHeight > 568 && BrowserWidth <= 412 && BrowserWidth > 320){
      final_epw = epwimage_667
    } else if( BrowserWidth <= 320 ){
      final_epw = epwimage_568
    } else if(BrowserHeight <= 414 && BrowserWidth <= 736 && BrowserWidth > 567 ){
      final_epw = epwimage_768
    } else {
      final_epw = epwimage
    }

    return (
      <div id="error404Container">
        <div id="errorpageWrapper" style={{paddingTop: Offsetheight + 'px'}}>
          {final_epw}
          <div id="errorTitle">
            <img src={ErrorLogo} alt="Error Logo" />
          </div>
          <div id="errorSubTitle">
            Looks like you're lost!
          </div>
          <div id="errorButtonLabel">
            Let's take a step back
          </div>
          <Link id="homeLink" to="/#" >Homepage</Link>
        </div>
      </div>
    )
  }
}

export default Dimensions()(Error404)
