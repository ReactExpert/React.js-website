import React , { Component } from 'react'
import moment from 'moment'
import '../styles/Chat.css'
import Header from '../../Header/components/Header.js'
import ChatHeader from './ChatHeader'
import ChatHistory from './ChatHistory'
import ChatFooter from './ChatFooter'
import UsersPanel from './UsersPanel'
import NewMatchesPanel from './NewMatchesPanel'
import Dimensions from 'react-dimensions'

import globalChatState from '../../Common/DefaultChatState'
import { markAllMessagesAsRead, onSendMessage, getMessagesWithUserIdSortedByDate } from '../../Common/ChatHelperFunctions'

class Chat extends Component {

  constructor (props) {
    super(props);

    //const localUserId = 29024;
    const remoteUserId1 = 39398,
        //remoteUserId2 = 55775,
        //remoteUserId3 = 11852,
        remoteUserId4 = 55581,
        remoteUserId5 = 71833,
        remoteUserId6 = 77777;

    this.state = {
      activeChatUserId:  remoteUserId1,
      newMatches: [ remoteUserId1, remoteUserId4, remoteUserId5, remoteUserId6 ],
      localUserId: globalChatState.localUserId,
      chatUsers: globalChatState.chatUsers,
      messages: globalChatState.messages,
      active: false
    };

    this.onSwitchActiveChatUser = this.onSwitchActiveChatUser.bind(this);
    this.onSwitchReturnChatUser = this.onSwitchReturnChatUser.bind(this);
    this.onSendMessage = onSendMessage.bind(this);
    this.markAllMessagesAsRead = markAllMessagesAsRead.bind(this);
  }

  render() {
    const { activeChatUserId, localUserId, chatUsers, newMatches, messages, active } = this.state;

    let distinctChatUserIds = [], distinctUsersWithUnreadMessages = [], numberOfUnreadMessages = 0;
    let lastMessageDictionary = {};
    messages.forEach((msg) => {
      let remoteUserId = msg.fromUserId !== localUserId ? msg.fromUserId : msg.toUserId;

      // Add each user to distinctChatUserIds
      if (distinctChatUserIds.indexOf(remoteUserId) < 0) {
        distinctChatUserIds.push(remoteUserId);
        lastMessageDictionary[remoteUserId.toString()] = {};
      }

      // Store most recent message for each user in dictionary
      let dictionaryItem = lastMessageDictionary[remoteUserId.toString()];
      const msgTimestamp = moment(msg.timestamp, 'YYYY-MM-DD HH:mm:ss');
      if (dictionaryItem.timestamp) {
        if (msgTimestamp.isAfter(dictionaryItem.timestamp)) {
          dictionaryItem.timestamp = msgTimestamp;
          dictionaryItem.lastMessage = msg.message;
        }
      } else {
        dictionaryItem.timestamp = msgTimestamp;
        dictionaryItem.lastMessage = msg.message;
      }

      if (msg.isRead === false) {

        numberOfUnreadMessages++;

        if (distinctUsersWithUnreadMessages.indexOf(remoteUserId < 0)) {
          distinctUsersWithUnreadMessages.push(remoteUserId);
        }

      }
    });

    const usersPanelUsers = chatUsers.filter((user) => { return distinctChatUserIds.indexOf(user.userId) > -1; });

    const activeChatUser = chatUsers.find((user) => { return user.userId === activeChatUserId; });

    const newMatchesUsers = chatUsers.filter((user) => { return newMatches.indexOf(user.userId) > -1; });

    const activeChatMessages = getMessagesWithUserIdSortedByDate(messages, activeChatUserId);

    const activestatus = chatUsers.filter((user) => { return user.userId});

    const BrowserWidth = this.props.containerWidth;
    let style, style1 = {};
    if( BrowserWidth > 1140 ){
      style = {display: 'block'};
    } else if( BrowserWidth <= 1140 ){
      style = active ? {display: 'none'} : {display: 'block'};
      style1 = active ? {display: 'block'} : {display: 'none'};
    }

    console.log(newMatchesUsers);

    return (
      <div id="chatContainer">
        <Header/>
        <div id="greyContainer">
          <div id="whiteContainer" style = {style}>
            <NewMatchesPanel
                users={newMatchesUsers}
                onNewMatchClick={this.onSwitchActiveChatUser}
            />
            <div id="horizontalContainer">
              <UsersPanel
                  chatUsers={usersPanelUsers}
                  onUserClick={this.onSwitchActiveChatUser}
                  lastMessageDictionary={lastMessageDictionary}
                  unreadMessages={numberOfUnreadMessages}
                  usersWithUnreadMessages={distinctUsersWithUnreadMessages}
              />
            </div>
          </div>
          <div id="chatPanelContainer" style = {style1}>
            <ChatHeader
                thumbnail={activeChatUser.thumbnail}
                firstName={activeChatUser.firstName}
                isFavorite={activeChatUser.isFavorite}
                astrologySymbol={activeChatUser.astrologySymbol}
                onUserReturnClick={this.onSwitchReturnChatUser}
            />
             <ChatHistory
                 localUserId={localUserId}
                 messages={activeChatMessages}
             />
             <ChatFooter
                 toUser={activeChatUserId}
                 onChatInputKeyDown={this.onSendMessage}
             />
          </div>
        </div>
      </div>
    );
  }

  onSwitchActiveChatUser(userId, event) {
    this.setState({ activeChatUserId: userId, active : true  });
    // TODO: Check if they are unread messages before
    this.markAllMessagesAsRead(userId);
  }
  onSwitchReturnChatUser(event){
    this.setState({ active : false  });

  }

}

export default Dimensions()(Chat)
