import React , { Component } from 'react'
import { Link } from 'react-router-dom'
import ValidatedInput from '../../../Common/components/ValidatedInput'
import { EmailValidator, UsernameValidator, PasswordValidator, DateValidator, TimeValidator } from '../../../../Validators/FormInputs'
import signupBackground  from '../../../images/Backgrounds/404page.png'
import signupBackground_768 from '../../../images/Backgrounds/404page_768.png'
import signupBackground_667 from '../../../images/Backgrounds/404page_667.png'
import signupBackground_568 from '../../../images/Backgrounds/404page_568.png'
import fbButton from '../../../images/fbbutton.png'
import active from '../../../images/active_underline.png'
import inactive from '../../../images/inactive_underline.png'

import '../styles/Signup.css'
import Dimensions from 'react-dimensions'

class Signup extends Component {

  constructor(props) {
    super(props);

    this.state = {
      dimensions: 0,
      email: {
        value: '',
        error: '',
        validator: EmailValidator
      },
      username: {
        value: '',
        error: '',
        validator: UsernameValidator
      },
      password: {
        value: '',
        error: '',
        validator: PasswordValidator
      },
      locationOfBirth: {
        value: '',
        error: ''
      },
      dateOfBirth: {
        value: '',
        error: '',
        validator: DateValidator
      },
      timeOfBirth: {
        value: '',
        error: '',
        validator: TimeValidator
      }
    };

    this.onImgLoad = this.onImgLoad.bind(this);
    this.onInputChange = this.onInputChange.bind(this);
  }

  onEmailChange(event) {
    const val = event.target.value;
    const errorText = EmailValidator(val);

    this.setState({
      email: {
        value: val,
        error: errorText
      }
    });
  }

  onInputChange(event) {
    const val = event.target.value;
    const name = event.target.name;
    const validator = this.state[name].validator;

    let errorText = '';
    if (typeof validator === 'function') {
      errorText = validator(val);
    }

    this.setState({ ...this.state,
      [name]: {
        value: val,
        error: errorText,
        validator: validator
      }
    });
  }

  onImgLoad({target:img}) {
    this.setState({
      dimensions: img.offsetHeight
    });
  }

  render() {
    /* Get Input Values From State */
    const { email, username, password, locationOfBirth, dateOfBirth, timeOfBirth } = this.state;

    /* Get Current Browser Height and Width */
    const BrowserHeight = this.props.containerHeight;
    const BrowserWidth = this.props.containerWidth;

    /* Get .imgContainer Height */
    const imgheight = this.state.dimensions;

    let Offsetheight = BrowserHeight - imgheight;
    if ( Offsetheight < 0 )
      Offsetheight = 0

    /* For Responsive Image Height */
    const signupimg = (
      <img id="signupimg" onLoad={this.onImgLoad} src={signupBackground} alt="Generic background" />
    );
    const signupimg_768 = (
      <img id="signupimg_768" onLoad={this.onImgLoad} src={signupBackground_768} alt="Generic background" />
    );
    const signupimg_667 = (
        <img id="signupimg_667" onLoad={this.onImgLoad} src={signupBackground_667} alt="667 Generic background" />
    );
    const signupimg_568 = (
        <img id="signupimg_568" onLoad={this.onImgLoad} src={signupBackground_568} alt="568 Generic background" />
    );

    let final_signup = null;
    if(BrowserHeight < 769 && BrowserHeight > 667 && BrowserWidth <= 1024 && BrowserWidth > 411){
      final_signup = signupimg_768
    } else if(BrowserHeight <= 667 && BrowserHeight > 568 && BrowserWidth <= 412 && BrowserWidth > 320){
      final_signup = signupimg_667
    } else if( BrowserWidth <= 320 ){
      final_signup = signupimg_568
    } else if(BrowserHeight <= 414 && BrowserWidth <= 736 && BrowserWidth > 567 ){
      final_signup = signupimg_768
    } else {
      final_signup = signupimg
    }

    return (

      <div id="signupContainer">

        <div id="imgContainer" style={{paddingTop: Offsetheight + 'px'}}>

          {/* Final Image Tag for responsive */}
          {final_signup}

          <div id="formContainer">

            <div id="linksContainer">
              <Link to="/signin"
                  id="signinLink">Sign in</Link>
              <img id="signinUnderline"
                   src={inactive}
                   alt="Inactive underline"/>

              <Link to="/signup"
                    id="signupLink"><strong>Sign up</strong></Link>
              <img id="signupUnderline"
                   src={active}
                   alt="Active underline"/>
            </div>

            <form>
              <ValidatedInput
                  inputClass=""
                  type="text"
                  placeholder="E-mail"
                  name="email"
                  value={email.value}
                  errorText={email.error}
                  onChange={this.onInputChange}
              />
              <ValidatedInput
                  inputClass=""
                  type="text"
                  placeholder="Username"
                  name="username"
                  value={username.value}
                  errorText={username.error}
                  onChange={this.onInputChange}
              />
              <ValidatedInput
                  inputClass=""
                  type="password"
                  placeholder="Password"
                  name="password"
                  value={password.value}
                  errorText={password.error}
                  onChange={this.onInputChange}
              />
              <ValidatedInput
                  inputClass=""
                  type="text"
                  placeholder="Location of Birth"
                  name="locationOfBirth"
                  value={locationOfBirth.value}
                  errorText={locationOfBirth.error}
                  onChange={this.onInputChange}
              />
              <ValidatedInput
                  inputClass=""
                  type="text"
                  placeholder="Date of Birth"
                  name="dateOfBirth"
                  value={dateOfBirth.value}
                  errorText={dateOfBirth.error}
                  onChange={this.onInputChange}
              />
              <ValidatedInput
                  inputClass=""
                  type="text"
                  placeholder="Time of Birth"
                  name="timeOfBirth"
                  value={timeOfBirth.value}
                  errorText={timeOfBirth.error}
                  onChange={this.onInputChange}
              />
              <span style={{
                textAlign : 'center',
                paddingRight: '45px',
                paddingTop: '34px'
              }}>
                 connect with
                <img id="fbButton"
                    src={fbButton}
                    alt="Facebook button"/>
              </span>
            </form>

          </div>

          <button id="submit">Next</button>

        </div>

      </div>
    )
  }

}

export default Dimensions()(Signup)
