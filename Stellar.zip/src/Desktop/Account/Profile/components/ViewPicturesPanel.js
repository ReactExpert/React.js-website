import React , { Component } from 'react'
import PropTypes from 'prop-types'
import '../styles/ViewPicturesPanel.css'
import leftArrow from '../../../images/leftarrow.png'
import rightArrow from '../../../images/rightarrow.png'
import relationship from '../../../images/relationshippurple.png'
import circle from '../../../images/inactive_underline.png'
import circledot from '../../../images/circledot.png'

export default class ViewPicturesPanel extends Component {

  static propTypes = {
    compatibilityText: PropTypes.string.isRequired,
    pictures: PropTypes.arrayOf(PropTypes.shape({
      title: PropTypes.string.isRequired,
      pics: PropTypes.string.isRequired
      }).isRequired).isRequired,
    selectedViewpicIndex: PropTypes.number.isRequired,
    onChangePicture: PropTypes.func.isRequired
  };

  render() {
    const { compatibilityText,selectedViewpicIndex, pictures, onChangePicture } = this.props;
    const picture = pictures[selectedViewpicIndex];
    console.log(onChangePicture);
    return (
      <div id="viewPicturePanelContainer">

        <div id="viewUserPictureContainer">
          <img
              src={leftArrow}
              className="vparrow"
              alt="left arrow"
              onClick={onChangePicture.bind(this, -1)}
          />
          <img
              id="userPicture"
              src={picture.pics}
              alt="user"
          />
          <img
              src={rightArrow}
              className="vparrow"
              alt="right arrow"
              onClick={onChangePicture.bind(this, 1)}
          />
          <div id="picpanPaginationContainer">
            {
              pictures.map(function(picture, index){
                const image = index === selectedViewpicIndex ? circledot : circle;
                return (
                  <img
                      src={image}
                      alt="circle"
                      key={picture.title}
                      onClick={onChangePicture.bind(this, index)}
                  />
                )
              }, this)
            }
          </div>
        </div>

        <div id="viewPicturePanelCompatibilityContainer">
          <img src={relationship} alt="relationship" />
          {compatibilityText}
        </div>

      </div>
    );
  }

}
