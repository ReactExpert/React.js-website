import React , { Component } from 'react';
import PropTypes from 'prop-types';
import checkmark from '../../../images/Icons/correct-white.png';
import close from '../../../images/close.png';


export default class CardButtonPanel extends Component {

  static propTypes = {
    userFavorite: PropTypes.bool.isRequired,
    onLikeButtonClick: PropTypes.func.isRequired,
    onNotInterestedButtonClick: PropTypes.func.isRequired
  };

  render(){
    const { userFavorite, onLikeButtonClick, onNotInterestedButtonClick } = this.props;

    return(
      <div className="cardButtonsContainer">
        <div
          className="cardButton"
          onClick={onLikeButtonClick}
        >
          <img
              className="checkmarkImage"
              src={checkmark}
              alt="Liked"
          />
        </div>
        <div className="cardButtonsSeparator"></div>
        <div
          className="cardButton"
          onClick={onNotInterestedButtonClick}
        >
          <img
              src={close}
              alt="Not Interested"
          />
        </div>
      </div>
    );
  }
}
