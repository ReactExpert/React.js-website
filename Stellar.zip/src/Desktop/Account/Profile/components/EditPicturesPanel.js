import React , { Component } from 'react'
import PropTypes from 'prop-types'

import leftarrow from '../../../images/leftarrow.png'
import rightarrow from '../../../images/rightarrow.png'
import circle from '../../../images/inactive_underline.png'
import circledot from '../../../images/circledot.png'

import '../styles/EditPicturesPanel.css'

export default class EditPicturesPanel extends Component {

  static propTypes = {
    pictures: PropTypes.arrayOf(PropTypes.shape({
      title: PropTypes.string.isRequired,
      pics: PropTypes.string.isRequired
      }).isRequired).isRequired,
    selectedEditpicIndex: PropTypes.number.isRequired,
    handleEditPicPagination: PropTypes.func.isRequired
  };

  render() {
    const { pictures, selectedEditpicIndex, handleEditPicPagination } = this.props;
    const picture = pictures[selectedEditpicIndex];

    // let mainPicture;
    // if (pictures.length > 0) {
    //   mainPicture = pictures[0];
    // } else {
    //   // TODO: Set default empty main picture
    // }

    return (
      <div id="picpanContainer">

        <div id="picpanSelectedPicContainer">
          <img className="picarrows"  alt="left arrow" src={leftarrow} />
          <img className="mainpic" alt="main profile" src={picture.pics} />
          <img className="picarrows"  alt="right arrow" src={rightarrow} />
        </div>

        <div id="picpanEmptyPicContainer">
          <EmptyPicture/>
          <EmptyPicture/>
          <EmptyPicture/>
          <EmptyPicture/>
        </div>
        <div id="picpanPaginationContainer">
          {
            pictures.map(function(picture, index){
              const image = index === selectedEditpicIndex ? circledot : circle;
              return (
                <img
                    src={image}
                    alt="circle"
                    key={picture.title}
                    onClick={handleEditPicPagination.bind(this, index)}
                />
              )
            }, this)
          }
        </div>

      </div>
    )
  }
}

function EmptyPicture(){
  return (
    <div className="emptyPicture"></div>
  )
}
