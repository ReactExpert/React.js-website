import React , { Component } from 'react'
import { Link } from 'react-router-dom'
import signupBackground  from '../../../images/Backgrounds/404page.png'
import signupBackground_768 from '../../../images/Backgrounds/404page_768.png'
import signupBackground_667 from '../../../images/Backgrounds/404page_667.png'
import signupBackground_568 from '../../../images/Backgrounds/404page_568.png'
import fbButton from '../../../images/fbbutton.png'
import active from '../../../images/active_underline.png'
import inactive from '../../../images/inactive_underline.png'
import '../styles/Signin.css'
import Dimensions from 'react-dimensions'

class Signin extends Component{
  constructor(props){
    super(props);
    this.state = {dimensions: 0};
    this.onImgLoad = this.onImgLoad.bind(this);
  }
  onImgLoad({target:img}) {
    this.setState({
      dimensions: img.offsetHeight
    });
  }
  render(){
    /* Get Current Browser Height and Width */
    const BrowserHeight = this.props.containerHeight;
    const BrowserWidth = this.props.containerWidth;

    /* Get .imgContainer Height */
    const imgheight = this.state.dimensions;

    let Offsetheight = BrowserHeight - imgheight;
    if ( Offsetheight < 0 )
      Offsetheight = 0

    /* For Responsive Image Height */
    const signinimg = (
      <img id="signinimg" onLoad={this.onImgLoad} src={signupBackground} alt="Generic background" />
    );
    const signinimg_768 = (
      <img id="signinimg_768" onLoad={this.onImgLoad} src={signupBackground_768} alt="Generic background" />
    );
    const signinimg_667 = (
        <img id="signinimg_667" onLoad={this.onImgLoad} src={signupBackground_667} alt="667 Generic background" />
    );
    const signinimg_568 = (
        <img id="signinimg_568" onLoad={this.onImgLoad} src={signupBackground_568} alt="568 Generic background" />
    );

    let final_signin = null;
    if(BrowserHeight < 769 && BrowserHeight > 667 && BrowserWidth <= 1024 && BrowserWidth > 411){
      final_signin = signinimg_768
    } else if(BrowserHeight <= 667 && BrowserHeight > 568 && BrowserWidth <= 412 && BrowserWidth > 320){
      final_signin = signinimg_667
    } else if( BrowserWidth <= 320 ){
      final_signin = signinimg_568
    } else if(BrowserHeight <= 414 && BrowserWidth <= 736 && BrowserWidth > 567 ){
      final_signin = signinimg_768
    } else {
      final_signin = signinimg
    }

    return (

      <div id="signinContainer">

        <div id="imgContainer" style={{paddingTop: Offsetheight + 'px'}}>

          {/* Final Image Tag for responsive */}
          {final_signin}

          <div id="formContainer" className="centeredText">

            <div id="linksContainer">
              <Link to="/signin"
                    id="signinLink"><strong>Sign in</strong></Link>
              <img id="signinUnderline"
                  src={active}
                alt="Inactive underline"/>

              <Link to="/signup"
                  id="signupLink">Sign up</Link>
              <img id="signupUnderline"
                src={inactive}
                alt="Active underline"/>
            </div>

            <form>
              <input type="text"
                  placeholder="Username"/>
              <input type="password"
                placeholder="Password"/>
              <span style={{
                textAlign : 'center',
                paddingRight: '45px',
                paddingTop: '34px'
              }}>
                 connect with
                <img id="fbButton"
                    src={fbButton}
                    alt="Facebook button"/>
              </span>
            </form>

            <br /> <br /> <br /> <br />
            <Link to="/forgotpassword"
                id="forgotPasswordLink">Forgot your password?</Link>

          </div>

          <button id="submit">Next</button>

        </div>

      </div>
    )
  }
}

export default Dimensions()(Signin)
