import React , { Component } from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import AstrologySymbolIcon from '../../Common/components/AstrologySymbolIcon'
import { UserProfileMatchPropTypes } from '../../../Validators/UserValidator'
import CardButtonPanel from '../../Account/Profile/components/CardButtonPanel.js'
import whiteHeart from '../../images/Icons/heart_white.svg'
import purpleHeart from '../../images/Icons/heart_purple.svg'

import '../styles/UserCard.css'

class UserCard extends Component {

  static propTypes = {
    user: UserProfileMatchPropTypes,
    onLikeButtonClick: PropTypes.func.isRequired,
    onNotInterestedButtonClick: PropTypes.func.isRequired,
    onFavouriteButtonClick: PropTypes.func.isRequired
  };

  render() {
    const { user, onLikeButtonClick, onNotInterestedButtonClick, onFavouriteButtonClick } = this.props;

    return (
      <div className="cardContainer item">

        <img src={user.mainPicture} alt="User"/>

        <img
            className="favouriteIcon"
            src={user.favorite ? purpleHeart : whiteHeart}
            alt="favourite"
            onClick={onFavouriteButtonClick.bind(this, user.userId)}
        />

        <div className="cardTextContainer">

          <div className="nameContainer">
            <Link to="/viewprofile">
              {user.firstName}, {user.age}
            </Link>
            <AstrologySymbolIcon
                imageClass="signImg"
                sign={user.astrologySymbol}
                isPurple={true}
            />
          </div>
          <span className="locationContainer">{`${user.city}, ${user.state}`}</span>

          <div className="cardBioContainer">
            {user.aboutMe}
          </div>

        </div>
        <CardButtonPanel
          userFavorite={user.favorite}
          onLikeButtonClick={onLikeButtonClick}
          onFavouriteButtonClick={onFavouriteButtonClick}
          onNotInterestedButtonClick={onNotInterestedButtonClick}
        />
      </div>
    )
  }

}

export default UserCard
