import  React , { Component } from 'react'
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom'
import '../../Common/components/ProfileThumbnailWithMask'

import logo from '../../images/Logo.png'
import leftarrow from '../../images/leftarrow.png'
import female from '../../images/female.png'
import smiley from '../../images/casual_search.png'
import searchIcon from '../../images/Icons/view_simple.png'
import msgIcon from '../../images/messages.png'
import signout from '../../images/Icons/signout.png'
import man from '../../images/man.png'
import woman from '../../images/woman.png'
import menuicon from '../../images/Icons/menu.png'

import daniel from '../../images/UserIcons/Large/Daniel.png'

import '../styles/Header.css'
import ProfileThumbnailWithMask from "../../Common/components/ProfileThumbnailWithMask";

import Drawer from 'material-ui/Drawer';
import MenuItem from 'material-ui/MenuItem';
import AppBar from 'material-ui/AppBar';
import IconButton from 'material-ui/IconButton';
import NavigationMenu from 'material-ui/svg-icons/navigation/menu';
import HeaderMenu from './HeaderMenu';
import ProfilePanelHeader from '../../Account/Profile/components/ProfilePanelHeader'
import AstrologySymbolIcon from '../../Common/components/AstrologySymbolIcon'

export default class Header extends Component {

  constructor(props) {
    super(props);
    this.state = {
      showProfileDropdownMenu: false,
      open: false,
      user: {
        firstName: 'Daniel',
        age: 24,
        gender: 'male',
        astrologySymbol: 'cancer'
      }
    };

    this.toggleProfileDropdownMenu = this.toggleProfileDropdownMenu.bind(this);
  }

  handleToggle = () => this.setState({open: !this.state.open});

  handleClose = () => this.setState({open: false});

  render() {
    const user = this.state.user;
    const styles =
      { title:
        {
         cursor: 'pointer',
         height: 36
        },
      };
    const profileDropdownStyle = this.state.showProfileDropdownMenu ? {} : { display: 'none' };
    return (
      <div>
        <div id="headerContainer">

          <Link to="/">
            <img src={logo} style={{ height: '49px'}} alt="Stellar logo"/>
          </Link>

          <div id="searchPanelContainer">
            <span>Looking for:</span>
            <img id="lookingForImage" className="searchParameterImage" src={smiley} alt="Smiley face"/>
            <span>With:</span>
            <img id="genderImage" className="searchParameterImage" src={female} alt="Gender"/>
            <span>Between:</span>
            <input id="betweenAgeInput" type="text" placeholder="21 - 37"/>
            <span>Location:</span>
            <input id="locationInput" type="text" placeholder="New York"/>
            <Link to="/exploration" id="searchButton">
              <img id="searchImage" src={searchIcon} alt="Search"/>
            </Link>
          </div>

          <div id="actionsContainer">

            <div className="actionsContainerButtonWrapper" onClick={this.toggleProfileDropdownMenu}>
              <ProfileThumbnailWithMask
                  className="actionsContainerButtonIcon"
                  thumbnail={daniel}
                  containerStyle={{ height: '41px', width: '41px'}}
              />
            </div>

            <Link className="actionsContainerButtonWrapper" to="/chat">
              <img
                  className="actionsContainerButtonIcon"
                  id="messagesLinkImage"
                  src={msgIcon}
                  alt="Messages"
              />
            </Link>

            <Link className="actionsContainerButtonWrapper" to="/signin">
              <img
                  className="actionsContainerButtonIcon"
                  id="signoutLinkImage"
                  src={signout}
                  alt="Sign out"
              />
            </Link>

            <div id="profileLinkDropdownContainer" style={profileDropdownStyle}>
              <div id="profileLinkDropdown">
                <HeaderMenu />
              </div>
            </div>

          </div>

        </div>
        <div id="SimpleTitleHeader">
          <AppBar
            title={
              <Link to="/">
                <img src={logo} style={styles.title} alt="Stellar logo"/>
              </Link>
            }
            titleStyle={{margin: '0 auto', height: 82, paddingTop: 8}}
            iconElementLeft={<img className="menuicon" src={menuicon} alt="MenuIcon" style={{color: '#5579ee', width: 24, height:24 , cursor: 'pointer'}} onClick={this.handleToggle} />}
            iconElementRight={
              <Link className="actionsContainerButtonWrapper" to="/chat">
                <img
                    className="actionsContainerButtonIcon"
                    id="messagesLinkImage"
                    src={msgIcon}
                    alt="Messages"
                    style={{width: 36, height:36}}
                />
              </Link>
            }
            iconStyleLeft={{padding: '24px 0 0 20px', marginRight: 0}}
            iconStyleRight={{paddingTop: 18}}
            style={{backgroundColor : '#fff'}}
          />
          <Drawer
            docked={false}
            width={280}
            open={this.state.open}
            onRequestChange={(open) => this.setState({open})}
          >
            <div id="MenuThumbnail">
              <ProfileThumbnailWithMask
                thumbnail={daniel}
                containerStyle={{ height: '118px', width: '118px'}}
              />
              <div id="ppNameText" className="ppHeaderMainText">
                <span>{user.firstName}, {user.age}</span>
                {}
                <img
                    id="ppGenderIcon"
                    alt="gender"
                    src={user.gender === 'male' ? man : woman}
                />
                <AstrologySymbolIcon
                    imageClass="ppAstrologyIcon"
                    sign={user.astrologySymbol}
                    isPurple={true}
                />
              </div>
            </div>
            <HeaderMenu />
            <div className="Logout">
              <MenuItem>
                <Link className="profileLinkDropdown-link" to="/signin">
                  <div className="profileLinkDropdown-icon-wrapper">
                    <img className="profileLinkDropdown-icon" id="signoutLinkImage" src={signout} alt="Sign out"/>
                  </div>
                  <div className="profileLinkDropdown-text-wrapper">
                    <div className="profileLinkDropdown-text">Log Out</div>
                  </div>
                </Link>
              </MenuItem>
            </div>
          </Drawer>
        </div>

      </div>
    )
  }

  toggleProfileDropdownMenu() {
    this.setState({
      showProfileDropdownMenu: !this.state.showProfileDropdownMenu
    });
  }
}

Header.propTypes = {
  title : PropTypes.string.isRequired
}
