import React , { Component } from 'react';
import PropTypes from 'prop-types';
import DotLink from '../../Horoscopes/components/DotLink';

export default class HpLinkHeader extends Component {

  static propTypes = {
    activeTab: PropTypes.string.isRequired,
    handleChangeTab: PropTypes.func.isRequired
  };

  render(){

    const { activeTab, handleChangeTab } = this.props;

    return(
        <div style={{display: 'flex', width: '100%', justifyContent: 'space-around'}}>
          <DotLink
              active={activeTab === 'daily'}
              activeStyle={{width: '60px', height: '7.73px'}}
              text="Daily"
              clickHandler={handleChangeTab.bind(this, 'daily')}
          />
          <DotLink
              active={activeTab === 'weekly'}
              activeStyle={{width: '80px'}}
              text="Weekly"
              clickHandler={handleChangeTab.bind(this, 'weekly')}
          />
          <DotLink
              active={activeTab === 'monthly'}
              activeStyle={{width: '90px'}}
              text="Monthly"
              clickHandler={handleChangeTab.bind(this, 'monthly')}
          />
      </div>
    );
  }
}
