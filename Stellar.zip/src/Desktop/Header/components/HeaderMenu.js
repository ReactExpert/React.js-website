import  React , { Component } from 'react'
import { Link } from 'react-router-dom'
import profile from '../../images/Icons/profile.png'
import settings from '../../images/Icons/settings.png'
import visible from '../../images/Icons/visible.png'
import personal_analysis from '../../images/Icons/personal_analysis.png'
import horoscope from '../../images/Icons/horoscope.png'
import info from '../../images/Icons/info.png'
import MenuItem from 'material-ui/MenuItem';

export default class HeaderMenu extends Component {
  render(){
    return(
      <div>
        <MenuItem>
          <Link className="profileLinkDropdown-link" to="/editprofile">
            <div className="profileLinkDropdown-icon-wrapper">
              <img className="profileLinkDropdown-icon" src={profile} alt="profile avatar" />
            </div>
            <div className="profileLinkDropdown-text-wrapper">
              <div className="profileLinkDropdown-text">Profile</div>
            </div>
          </Link>
        </MenuItem>

        <MenuItem>
          <Link className="profileLinkDropdown-link" to="/preferences">
          <div className="profileLinkDropdown-icon-wrapper">
            <img className="profileLinkDropdown-icon" src={visible} alt="eye" />
          </div>
          <div className="profileLinkDropdown-text-wrapper">
            <div className="profileLinkDropdown-text">Search Preferences </div>
          </div>
          </Link>
        </MenuItem>

        <MenuItem>
          <Link className="profileLinkDropdown-link" to="/analysis">
          <div className="profileLinkDropdown-icon-wrapper">
            <img className="profileLinkDropdown-icon" src={personal_analysis} alt="chart" />
          </div>
          <div className="profileLinkDropdown-text-wrapper">
            <div className="profileLinkDropdown-text">Personal Analysis</div>
          </div>
          </Link>
        </MenuItem>

        <MenuItem>
          <Link className="profileLinkDropdown-link" to="/horoscopes">
          <div className="profileLinkDropdown-icon-wrapper">
            <img className="profileLinkDropdown-icon" src={horoscope} alt="horoscope" />
          </div>
          <div className="profileLinkDropdown-text-wrapper">
            <div className="profileLinkDropdown-text">Horoscopes</div>
          </div>
          </Link>
        </MenuItem>

        <MenuItem>
          <Link className="profileLinkDropdown-link" to="/settings">
          <div className="profileLinkDropdown-icon-wrapper">
            <img className="profileLinkDropdown-icon" src={settings} alt="gears" />
          </div>
          <div className="profileLinkDropdown-text-wrapper">
            <div className="profileLinkDropdown-text">Account Settings</div>
          </div>
          </Link>
        </MenuItem>

        <MenuItem>
          <Link className="profileLinkDropdown-link" to="/faq">
          <div className="profileLinkDropdown-icon-wrapper">
            <img className="profileLinkDropdown-icon" src={info} alt="info" />
          </div>
          <div className="profileLinkDropdown-text-wrapper">
            <div className="profileLinkDropdown-text">FAQ</div>
          </div>
          </Link>
        </MenuItem>
      </div>
    );
  }
};
