import React , { Component } from 'react'
import PropTypes from 'prop-types'
import Report from './Report'

import circledot from '../../images/circledot.png'
import circle from '../../images/inactive_underline.png'
import '../styles/ReportsPanel.css'

class ReportsPanel extends Component{

  static propTypes = {
    reports: PropTypes.arrayOf(PropTypes.shape({
      title: PropTypes.string.isRequired,
      content: PropTypes.string.isRequired
    }).isRequired).isRequired,
    selectedReportIndex: PropTypes.number.isRequired,
    handleReportPagination: PropTypes.func.isRequired,
    active: PropTypes.bool.isRequired,
    browserWidth:PropTypes.number.isRequired
  };

  render(){
    const { active, reports, selectedReportIndex, handleReportPagination, browserWidth } = this.props;
    const report = reports[selectedReportIndex];
    let style = {};

    if( browserWidth > 970 ){
      style = {display: 'block'};
    } else if( browserWidth <= 970 ){
      style = active ? {display: 'block'} : {display: 'none'};
    }
    return (
      <div id="rpContainer" style={style}>

        <h3 className="panelTitle">Reports</h3>
        <Report
            title={report.title}
            content={report.content}
        />
        <div id="rpPaginationContainer">
          {
            reports.map(function(report, index){
              const image = index === selectedReportIndex ? circledot : circle;
              return (
                <img
                    src={image}
                    alt="circle"
                    key={report.title}
                    onClick={handleReportPagination.bind(this, index)}
                />
              )
            }, this)
          }

        </div>
      </div>
    )
  }

}
export default ReportsPanel
