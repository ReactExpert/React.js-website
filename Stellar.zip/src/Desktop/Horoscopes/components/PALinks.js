import React , { Component } from 'react';
import PropTypes from 'prop-types';

export default class PALink extends Component {
  static propTypes = {
    active: PropTypes.bool.isRequired,
    text: PropTypes.string.isRequired,
    clickHandler: PropTypes.func.isRequired    
  }

  render(){
    const { active, text, clickHandler } = this.props;
    let linkClass = 'selected PALink';
    if (!active) {
      linkClass = 'notSelected PALink';
    }
    return(
      <div id="PALinkContainer">
        <a onClick={clickHandler} className={linkClass}> {text} </a>
      </div>
    );
  }
}
