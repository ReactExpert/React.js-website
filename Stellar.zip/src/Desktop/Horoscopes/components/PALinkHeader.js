import React , { Component } from 'react';
import PropTypes from 'prop-types';
import PALink from './PALinks'

export default class PALinkHeader extends Component {
  static propTypes = {
    activeTab: PropTypes.string.isRequired,
    handleChangeTab: PropTypes.func.isRequired
  }

  render(){

    const { activeTab, handleChangeTab } = this.props;

    return(
      <div id="PATabHeader">
        <PALink
            active={activeTab === 'natalchart'}
            text="Natal Chart"
            clickHandler={handleChangeTab.bind(this, 'natalchart')}
        />
        <PALink
            active={activeTab === 'reports'}            
            text="Reports"
            clickHandler={handleChangeTab.bind(this, 'reports')}
        />
      </div>
    );
  }
}
