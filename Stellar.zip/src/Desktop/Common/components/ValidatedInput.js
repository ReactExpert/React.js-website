import React, { Component } from 'react'
import PropTypes from 'prop-types'

import '../styles/ValidatedInput.css'

export default class ValidatedInput extends Component {

  static propTypes = {
    inputClass: PropTypes.string,
    type: PropTypes.string,
    placeholder: PropTypes.string,
    name: PropTypes.string,
    value: PropTypes.string.isRequired,
    errorText: PropTypes.string.isRequired,
    onChange: PropTypes.func.isRequired
  };

  render() {
    let { inputClass, type, placeholder, name, value, errorText, onChange } = this.props;

    if (inputClass) {
      inputClass += ' validated-input';
    } else {
      inputClass = 'validated-input'
    }

    if (errorText !== '') {
      inputClass += ' validated-input-error';
    }

    return (
      <div className="validated-input-wrapper">
        <input
            className={inputClass}
            type={type ? type : 'text'}
            placeholder={placeholder ? placeholder : ''}
            name={name ? name : ''}
            value={value}
            onChange={onChange}
        />
        <div className="validated-input-error-text">
          {errorText}
        </div>
      </div>
    );
  }

}
